import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: [ './header.component.scss','../../assets/styles/main.scss' ]
})
export class HeaderComponent {
}
