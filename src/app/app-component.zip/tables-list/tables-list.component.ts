import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tables-list',
  templateUrl: './tables-list.component.html',
  styleUrls: ['./tables-list.component.scss', '../../assets/styles/main.scss',]
})
export class TablesListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
