import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [
    '../assets/styles/main.scss',
    './app.component.scss'
  ]
})
export class AppComponent {
  title = 'xenfax-ui';
}
