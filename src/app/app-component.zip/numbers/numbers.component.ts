import { Component } from '@angular/core';

@Component({
  selector: 'app-numbers',
  templateUrl: './numbers.component.html',
  styleUrls: [ './numbers.component.scss' ,'../../assets/styles/main.scss']
})
export class NumbersComponent {
}
