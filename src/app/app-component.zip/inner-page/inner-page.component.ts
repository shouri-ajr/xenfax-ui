import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inner-page',
  templateUrl: './inner-page.component.html',
  styleUrls: ['./inner-page.component.scss','../../assets/styles/main.scss' ]
})
export class InnerPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
